/** 
* @create-date :${YEAR}-${MONTH_NAME_SHORT}-${DATE}-${TIME} 
* @name : ${NAME}
*/
<template>
#[[$END$]]#
</template>

<script>
export default {
  name: "${NAME}",
  components:{},
  props:{},
  data(){
    return {}
    },
  computed:{},
  created(){},
  mounted(){},
  methods:{},
}
</script>

<style scoped lang='scss' type="text/scss">

</style>